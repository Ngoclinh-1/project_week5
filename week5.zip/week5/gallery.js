/* ==========================================================
   HÀM KHỞI TẠO ĐƯỢC GỌI KHI TRANG TẢI XONG (ONLOAD)
   ========================================================== */
function initializeGallery() {
    // 1. Console.log xác nhận sự kiện onload đã chạy
    console.log("Trang web đã tải xong! Hàm initializeGallery() bắt đầu chạy.");

    // 2. Lấy danh sách tất cả các ảnh thu nhỏ
    var images = document.querySelectorAll(".preview");
    console.log("Tổng số ảnh tìm thấy: " + images.length);

    // 3. Sử dụng vòng lặp for để duyệt qua từng ảnh và thêm thuộc tính tabindex
    for (var i = 0; i < images.length; i++) {
        images[i].setAttribute("tabindex", "0");
        console.log("Đã thêm thuộc tính tabindex='0' cho ảnh thứ: " + (i + 1));
    }
}

/* ==========================================================
   HÀM CẬP NHẬT KHI RÊ CHUỘT (MOUSEOVER) HOẶC TAB TỚI (FOCUS)
   ========================================================== */
function upDate(previewPic) {
    // In thông tin kiểm tra ra console
    console.log("Sự kiện Focus / Mouseover kích hoạt thành công!");
    console.log("Alt Text: " + previewPic.alt);
    console.log("Image Source: " + previewPic.src);

    // Lấy phần tử khung hiển thị
    var displayDiv = document.getElementById("image");

    // Cập nhật văn bản và hình nền
    displayDiv.innerHTML = previewPic.alt;
    displayDiv.style.backgroundImage = "url('" + previewPic.src + "')";
}

/* ==========================================================
   HÀM KHÔI PHỤC KHI RỜI CHUỘT (MOUSEOUT) HOẶC RỜI FOCUS (BLUR)
   ========================================================== */
function unDo() {
    console.log("Sự kiện Blur / Mouseout kích hoạt, đặt lại trạng thái ban đầu.");

    // Lấy phần tử khung hiển thị
    var displayDiv = document.getElementById("image");

    // Khôi phục hình nền rỗng và đoạn văn bản mặc định ban đầu
    displayDiv.style.backgroundImage = "url('')";
    displayDiv.innerHTML = "Hover over an image below or use Tab to display here.";
}